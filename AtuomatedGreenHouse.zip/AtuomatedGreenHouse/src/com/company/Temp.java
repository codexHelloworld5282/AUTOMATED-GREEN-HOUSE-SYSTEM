/**

 The Temp class represents an automated greenhouse system GUI that allows the user to enter
 current temperature, desired temperature, furnace heating rate, and AC cooling rate.
 The user can start, stop, save and view simulations of the system.
 The class implements ActionListener to handle button clicks.
 */
package com.company;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;

public class Temp extends JFrame implements ActionListener {
     Vector<Vector<String>> data1; // stores the saved simulation data
     JLabel currentTempLabel;
     JTextField currentTempField;
     JLabel desiredTempLabel;
     JTextField desiredTempField;
     JLabel furnaceRateLabel;
     JTextField furnaceRateField;
     JLabel acRateLabel;
     JTextField acRateField;
     JButton startButton;
     JButton stopButton;
     JButton back;
     JButton save1;
     JButton view1;
     JTextArea logArea;
    private double currentTemp;
    private double desiredTemp;
    private double furnaceRate;
    private double acRate;
    private boolean furnaceOn;
    private boolean acOn;
    private boolean running;

    /**
     * Constructs a new Temp object that initializes the GUI with labels, text fields, and buttons
     * and sets their positions and actions
     */
    public Temp() {
        super("Temperature Control");
        currentTempLabel = new JLabel("Current Temperature:");
        currentTempField = new JTextField("0.0", 10);
        desiredTempLabel = new JLabel("Desired Temperature:");
        desiredTempField = new JTextField("20.0", 10);
        furnaceRateLabel = new JLabel("Furnace Heating Rate:");
        furnaceRateField = new JTextField("1.0", 10);
        acRateLabel = new JLabel("AC Cooling Rate:");
        acRateField = new JTextField("1.0", 10);
        startButton = new JButton("Start");
        stopButton = new JButton("Stop");
        save1 = new JButton("Save");
        view1 = new JButton("View");
        back = new JButton("Back to main");
        logArea = new JTextArea(10, 40);
        JScrollPane scrollPane = new JScrollPane(logArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        data1= new Vector<>(); // initialize the data here

        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        inputPanel.add(currentTempLabel);
        inputPanel.add(currentTempField);
        inputPanel.add(desiredTempLabel);
        inputPanel.add(desiredTempField);
        inputPanel.add(furnaceRateLabel);
        inputPanel.add(furnaceRateField);
        inputPanel.add(acRateLabel);
        inputPanel.add(acRateField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        buttonPanel.add(save1);
        buttonPanel.add(view1);
        buttonPanel.add(back);

        JPanel logPanel = new JPanel(new BorderLayout());
        logPanel.setBorder(BorderFactory.createTitledBorder("Log"));
        logPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(inputPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        mainPanel.add(logPanel, BorderLayout.NORTH);

        setContentPane(mainPanel);
        pack();
        setVisible(true);
        setBounds(450,100,600,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        startButton.addActionListener(this);
        stopButton.addActionListener(this);
        save1.addActionListener(this);
        view1.addActionListener(this);
        back.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == save1) {
            try {

                String fileName ="temp.text";
                File file = new File(fileName);
                if (!file.exists()) {
                    file.createNewFile();
                }
                FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(currentTempField.getText()+ " " + desiredTempField.getText() +" "+
                        furnaceRateField.getText()+" "+acRateField.getText()+" \n");

                bw.close();
                fw.close();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }}
        else if (e.getSource() ==
                view1) {
            BufferedReader br = null;
            try {
                String fileName = "temp.text";
                File file = new File(fileName);
                if (!file.exists()) {
                    JOptionPane.showMessageDialog(null, "No simulation saved yet!", "Warning", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                br = new BufferedReader(new FileReader(file));
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim(); // remove any leading/trailing whitespace
                    if (line.isEmpty()) {
                        continue; // skip empty lines
                    }
                    Vector<String> row = new Vector<>();
                    String[] parts = line.split(" ");
                    row.add(parts[0]);
                    row.add(parts[1]);
                    if (parts.length >= 4) {
                        row.add(parts[2]);
                        row.add(parts[3]);

                    }
                    data1.add(row);
                }
                String[] columnNames = {"Current temp","Desired temp","Furnace rate","AC rate"};
                String[][] dataArray = new String[data1.size()][2];
                for (int i = 0; i < data1.size(); i++) {
                    dataArray[i] = data1.get(i).toArray(new String[0]);
                }
                DefaultTableModel model = new DefaultTableModel(dataArray, columnNames);
                JTable table = new JTable(model);
                JFrame frame = new JFrame("Simulations");
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.getContentPane().add(new JScrollPane(table));
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        else if (e.getSource() == startButton) {
            start();
        } else if (e.getSource() == stopButton) {
            stop();
        }
        else if(e.getSource()==back)
        {
            new AutomatedGreenHouse().setVisible(true);
            setVisible(false);
        }
    }

    private void start() {
        try {
            currentTemp = Double.parseDouble(currentTempField.getText());
            desiredTemp = Double.parseDouble(desiredTempField.getText());
            furnaceRate = Double.parseDouble(furnaceRateField.getText());
            acRate = Double.parseDouble(acRateField.getText());
        } catch (NumberFormatException ex) {
            log("Invalid input format");
            return;
        }
        furnaceOn = false;
        acOn = false;
        running = true;
        log("Temperature control started.");
        // start a new thread to update temperature and control furnace and AC
        new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(1000); // wait for 1 second
                } catch (InterruptedException ex) {
                    // do nothing
                }
                // update temperature
                if (furnaceOn) {
                    currentTemp += furnaceRate;
                } else if (acOn) {
                    currentTemp -= acRate;
                }
                // check if temperature is within desired range
                if (currentTemp < desiredTemp) {
                    // turn on furnace
                    furnaceOn = true;
                    acOn = false;
                    log("Furnace turned on");
                } else if (currentTemp > desiredTemp) {
                    // turn on AC
                    acOn = true;
                    furnaceOn = false;
                    log("AC turned on");
                } else {
                    // turn off furnace and AC
                    furnaceOn = false;
                    acOn = false;
                    log("Furnace and AC turned off");
                }
                currentTempField.setText(String.format("%.1f", currentTemp));
            }
        }).start();
    }

    private void stop() {
        running = false;
        log("Temperature control stopped.");
    }

    private void log(String message) {
        SwingUtilities.invokeLater(() -> logArea.append(message + "\n"));
    }}