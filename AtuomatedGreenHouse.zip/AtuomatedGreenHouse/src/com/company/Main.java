/**

 The Main class is the entry point for the AutomatedGreenHouse program.
 It creates an instance of AutomatedGreenHouse and starts the application.
 */
package com.company;
public class Main {
    /**
     * The main method is the entry point of the program.
     * It creates a new instance of AutomatedGreenHouse and starts the application.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {

        new AutomatedGreenHouse();

    }
}

