/**

 The AutomatedGreenHouse class extends the JFrame class to create a GUI for the Automated Green House Control System.
 It implements the ActionListener interface to handle button click events.
 */
package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AutomatedGreenHouse extends JFrame implements ActionListener {
    JLabel label, label1;

    JButton temp, soil, humidity;

    /**
     * The constructor for AutomatedGreenHouse class.
     * It sets the title and layout for the JFrame.
     * It adds a welcome message and choice label to the JFrame.
     * It adds buttons for temperature, soil moisture and humidity to the JFrame.
     * It sets the bounds and visibility of the JFrame.
     */
    public AutomatedGreenHouse() {
        setTitle("Automated Green House Control System");
        setLayout(null);

        //Welcome text
        label = new JLabel("WELCOME TO AUTOMATED GREENHOUSE SYSTEM");
        label.setFont(new Font("Arial black", Font.PLAIN, 18));
        label.setBounds(30, 20, 600, 50);
        add(label);

        //make choice
        label1 = new JLabel("Make a choice!");
        label1.setFont(new Font("Arial ", Font.BOLD, 20));
        label1.setBounds(230, 60, 600, 50);
        add(label1);

        //adding buttons for temp/soil and humidity
        temp = new JButton("Temperature");
        temp.setBounds(230, 120, 130, 30);
        temp.addActionListener(this);
        add(temp);

        soil = new JButton("Soil Moisture");
        soil.setBounds(230, 180, 130, 30);
        soil.addActionListener(this);
        add(soil);

        humidity = new JButton("Humidity");
        humidity.setBounds(230, 240, 130, 30);
        humidity.addActionListener(this);
        add(humidity);

        pack();
        //Setting the bounds of the Jframe
        //x&y are the location coordinates
        //Where other 2 are deciding the width and height of Jframe
        //it can also be done by2 methods separately
        //By setLocation & setSize
        setBounds(450, 100, 600, 400);
        //Here is the DefaultCloseOperation is used
        //It will terminate the program when we click on the Close button
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //Making the Jframe Visible
        setVisible(true);
    }

    /**
     * The actionPerformed method handles button click events.
     * If the soil button is clicked, it creates a new instance of the soil class and sets the current JFrame to invisible.
     * If the temperature button is clicked, it creates a new instance of the Temp class and sets the current JFrame to invisible.
     * If the humidity button is clicked, it creates a new instance of the Humidity class and sets the current JFrame to invisible.
     *
     * @param e the ActionEvent object containing information about the event.
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == soil) {
            new soil();
            setVisible(false);
        } else if (e.getSource() == temp) {
            new Temp();
            setVisible(false);
        } else if (e.getSource() == humidity) {
            new Humidity();
            setVisible(false);
        }
    }
}