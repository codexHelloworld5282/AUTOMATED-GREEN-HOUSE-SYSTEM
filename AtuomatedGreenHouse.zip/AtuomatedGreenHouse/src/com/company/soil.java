package com.company;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Vector;

/**

 The soil class implements an interface for controlling soil moisture.
 */
public class soil extends JFrame implements ActionListener {

    Vector<Vector<String>> data3; // Vector to store data
    boolean sprinklerState = false; // flag for sprinkler on/off state
    int currentMoisture = 0; // current soil moisture level
    JToggleButton sprinklerToggleButton; // toggle button for sprinkler on/off
    JLabel humidityLabel;
    JLabel moistureLabel; // label to display current soil moisture level
    JLabel sampleIncLabel, Range, Rate; // labels for sample increment, desired moisture range, and moisture rate
    JTextField sampleIncrementInput, rangeInput, RateInput; // text fields for sample increment, desired moisture range, and moisture rate
    JButton updateButton, backButton; // buttons for updating, going back to main
    JButton save3, view3; // buttons for saving and viewing data
    JTextArea logArea; // text area for logging

    /**
     * Constructor for creating a new instance of soil.
     */
    public soil() {
        data3 = new Vector<>(); // initialize the data here
        setTitle("Soil moisture control");
        setLayout(null);
        logArea = new JTextArea(10, 50);
        JScrollPane scrollPane = new JScrollPane(logArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        JPanel logPanel = new JPanel();
        logPanel.setBounds(0, 0, 600, 190);

        logPanel.setBorder(BorderFactory.createTitledBorder("Log"));
        logPanel.add(scrollPane, BorderLayout.CENTER);
        add(logPanel, BorderLayout.NORTH);

        sampleIncLabel = new JLabel("Sample Increment :");
        sampleIncLabel.setBounds(50, 175, 165, 50);
        add(sampleIncLabel);

        sampleIncrementInput = new JTextField("0");
        sampleIncrementInput.setBounds(210, 190, 290, 20);
        add(sampleIncrementInput);

        Range = new JLabel("Desired moisture Range:");
        Range.setBounds(50, 200, 165, 50);
        add(Range);

        rangeInput = new JTextField("0");
        rangeInput.setBounds(210, 215, 290, 20);
        add(rangeInput);

        Rate = new JLabel("Moisture Rate:");
        Rate.setBounds(50, 225, 165, 50);
        add(Rate);

        RateInput = new JTextField("0");
        RateInput.setBounds(210, 240, 290, 20);
        add(RateInput);

        moistureLabel = new JLabel("Current soil moisture: " + currentMoisture + "%");
        moistureLabel.setBounds(50, 255, 165, 50);
        add(moistureLabel);

        updateButton = new JButton("Update");
        updateButton.addActionListener(this);
        updateButton.setBounds(100, 300, 80, 20);
        add(updateButton);

        sprinklerToggleButton = new JToggleButton("Sprinkler_Off");
        sprinklerToggleButton.addActionListener(this);
        sprinklerToggleButton.setBounds(400, 300, 150, 20);
        add(sprinklerToggleButton);

        backButton = new JButton("Back to main");
        backButton.addActionListener(this);
        backButton.setBounds(400, 335, 150, 20);
        add(backButton);

        save3 = new JButton("Save");
        save3.addActionListener(this);
        view3 = new JButton("view");
        view3.addActionListener(this);

        save3.setBounds(200, 300, 80, 20);
        add(save3);
        view3.setBounds(300, 300, 80, 20);
        add(view3);

        pack();pack();
        //Setting the bounds of the Jframe
        //x&y are the location coordinates
        //Where other 2 are deciding the width and height of Jframe
        //it can also be done by2 methods separately
        //By setLocation & setSize
        setBounds(450,100,600,400);
        //Here is the DefaultCloseOperation is used
        //It will terminate the program when we click on the Close button
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //Making the Jframe Visible
        setVisible(true);
    }/**
     * Invoked when an action occurs.
     *
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == updateButton) {
            logArea.setText(logArea.getText()+"Update button pressed!"+"\n");
            int sampleIncrement = Integer.parseInt(sampleIncrementInput.getText());
            int desiredMoisture = Integer.parseInt(rangeInput.getText());
            int moisturizingRate = Integer.parseInt(RateInput.getText());

            // start a new thread for measuring soil moisture
            new Thread(() -> {
                // simulate measuring soil moisture
                currentMoisture += (sampleIncrement + moisturizingRate);

                // update moisture label
                SwingUtilities.invokeLater(() -> moistureLabel.setText("Current soil Moisture: " + currentMoisture + "%"));
                logArea.setText(logArea.getText()+"Current soil Moisture: "+currentMoisture+"%\n");
                // check if sprinkler should be turned on or off
                if (currentMoisture < desiredMoisture) {
                    sprinklerState = true;
                    sprinklerToggleButton.setText("Sprinkler_On");
                    logArea.setText(logArea.getText()+sprinklerToggleButton.getText()+"\n");

                } else {
                    sprinklerState = false;
                    sprinklerToggleButton.setText("Sprinkler_Off");
                    logArea.setText(logArea.getText()+sprinklerToggleButton.getText()+"\n");
                }
            }).start();
        } else if (e.getSource() == sprinklerToggleButton) {
            sprinklerState = !sprinklerState;
            if (sprinklerState) {
                sprinklerToggleButton.setText("Sprinkler_On");
                logArea.setText(logArea.getText()+sprinklerToggleButton.getText()+"\n");
            } else {
                sprinklerToggleButton.setText("Sprinkler_Off");
                logArea.setText(logArea.getText()+sprinklerToggleButton.getText()+"\n");
            }
        }

        else if(e.getSource()==backButton)
        {
            new AutomatedGreenHouse().setVisible(true);
            setVisible(false);
        }
        else //for saving and viewing soil data
            if (e.getSource() == save3) {
                try {

                    String fileName ="soil.text";
                    File file = new File(fileName);
                    if (!file.exists()) {
                        file.createNewFile();
                    }
                    FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write(sampleIncrementInput.getText()+ " " + rangeInput.getText() +" "+RateInput.getText()+" "+currentMoisture+" "+
                            sprinklerToggleButton.getText()+" \n");
                    bw.close();
                    fw.close();
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }}
            else if (e.getSource() == view3) {
                BufferedReader br = null;
                try {
                    String fileName = "soil.text";
                    File file = new File(fileName);
                    if (!file.exists()) {
                        JOptionPane.showMessageDialog(null, "No simulation saved yet!", "Warning", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    br = new BufferedReader(new FileReader(file));
                    String line;
                    while ((line = br.readLine()) != null) {
                        line = line.trim(); // remove any leading/trailing whitespace
                        if (line.isEmpty()) {
                            continue; // skip empty lines
                        }
                        Vector<String> row1 = new Vector<>();
                        String[] parts1 = line.split(" ");
                        row1.add(parts1[0]);
                        row1.add(parts1[1]);
                        if (parts1.length >= 5) {
                            row1.add(parts1[2]);
                            row1.add(parts1[3]);
                            row1.add(parts1[4]);

                        }
                        data3.add(row1);
                    }
                    String[] columnNames = {"Sample Inc","Range","Rate:","Current Moisture","Sprinkler"};
                    String[][] dataArray = new String[data3.size()][2];
                    for (int i = 0; i < data3.size(); i++) {
                        dataArray[i] = data3.get(i).toArray(new String[0]);
                    }
                    DefaultTableModel model1 = new DefaultTableModel(dataArray, columnNames);
                    JTable table1= new JTable(model1);
                    JFrame frame1 = new JFrame("Simulations");
                    frame1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    frame1.getContentPane().add(new JScrollPane(table1));
                    frame1.pack();
                    frame1.setLocationRelativeTo(null);
                    frame1.setVisible(true);

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
    }
}