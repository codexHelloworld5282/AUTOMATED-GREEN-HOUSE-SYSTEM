/**

 Humidity class represents the humidity control in the automated greenhouse system.
 It extends JFrame and implements ActionListener and Runnable interfaces.
 */
package com.company;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Vector;

public class Humidity extends JFrame implements ActionListener, Runnable {JTextArea logArea;
    Vector<Vector<String>> data3; // data for table
    boolean humidifierState = false;
    int currentHumidity = 0;
    int humidityUpdateInterval = 3; // interval for humidity updates
    int humidifyingRate, desiredHumidity; // rate of humidity and desired humidity

    JToggleButton humidifierToggleButton; // toggle button for turning humidifier on or off
    JLabel humidityLabel; // label for displaying current humidity
    JLabel sampleIncLabel, Range, Rate; // labels for input fields
    JTextField sampleIncrementInput, rangeInput, RateInput; // input fields for humidity range, sample increment, and humidifying rate
    JButton updateButton, backButton, save3, view3; // buttons for updating, going back, saving data, and viewing data

    public Thread humidityThread;

/**
 * Constructor for the Humidity class.
 * Initializes the GUI components and starts the humidityThread.
 */ public Humidity()
{
    logArea = new JTextArea(10, 50);
    JScrollPane scrollPane = new JScrollPane(logArea);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    JPanel logPanel = new JPanel();
    logPanel.setBounds(0,0,600,190);

    logPanel.setBorder(BorderFactory.createTitledBorder("Log"));
    logPanel.add(scrollPane, BorderLayout.CENTER);
    add(logPanel, BorderLayout.NORTH);

    data3= new Vector<>(); // initialize the data here
    setTitle("Automated Green House Control System");
    setLayout(null);

    sampleIncLabel=new JLabel("Sample Increment :");
    sampleIncLabel.setBounds(50,175,165,50);
    add(sampleIncLabel);

    sampleIncrementInput=new JTextField("0");
    sampleIncrementInput.setBounds(210,190,290,20);
    add(sampleIncrementInput);

    Range=new JLabel("Desired Humidity Range:");
    Range.setBounds(50,200,165,50);
    add(Range);

    rangeInput=new JTextField("0");
    rangeInput.setBounds(210,215,290,20);
    add(rangeInput);

    Rate=new JLabel("Humidifying Rate:");
    Rate.setBounds(50,225,165,50);
    add(Rate);

    RateInput=new JTextField("0");
    RateInput.setBounds(210,240,290,20);
    add(RateInput);

    humidityLabel = new JLabel("Current Humidity: " + currentHumidity + "%");
    humidityLabel.setBounds(50,255,165,50);
    add(humidityLabel);

    updateButton = new JButton("Update");
    updateButton.addActionListener(this);
    updateButton.setBounds(100,300,80,20);
    add(updateButton);

    humidifierToggleButton = new JToggleButton("Humidifier_Off");
    humidifierToggleButton.addActionListener(this);
    humidifierToggleButton.setBounds(400,300,150,20);
    add(humidifierToggleButton);

    humidityThread = new Thread(this);

    backButton = new JButton("Back to main");
    backButton.addActionListener(this);
    backButton.setBounds(400,335,150,20);
    add(backButton);

    save3= new JButton("Save");
    save3.addActionListener(this);
    view3= new JButton("view");
    view3.addActionListener(this);

    save3.setBounds(200,300,80,20);
    add(save3);
    view3.setBounds(300,300,80,20);
    add(view3);


    humidityThread.start();
    // check if humidifier should be turned on or off
    desiredHumidity = Integer.parseInt(rangeInput.getText());
    humidifyingRate = Integer.parseInt(RateInput.getText());


    pack();
    //Setting the bounds of the Jframe
    //x&y are the location coordinates
    //Where other 2 are deciding the width and height of Jframe
    //it can also be done by2 methods separately
    //By setLocation & setSize
    setBounds(450,100,600,400);
    //Here is the DefaultCloseOperation is used
    //It will terminate the program when we click on the Close button
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    //Making the Jframe Visible
    setVisible(true);
    setTitle("Humidity Control");

}

    public void run() {
        while (true) {
            try {
                Thread.sleep(humidityUpdateInterval * 1000L);



                // adjust current humidity based on humidifying rate
                if (humidifierState && currentHumidity < desiredHumidity) {
                    currentHumidity += humidifyingRate;
                } else if (!humidifierState && currentHumidity > 0) {
                    currentHumidity -= humidifyingRate;
                }

                // update humidity label
                SwingUtilities.invokeLater(() -> humidityLabel.setText("Current Humidity: " + currentHumidity + "%"));
                logArea.setText(logArea.getText()+humidityLabel.getText()+"\n");

                // check if humidifier should be turned on or off based on updated humidity
                if (currentHumidity < desiredHumidity && !humidifierState) {
                    humidifierState = true;
                    humidifierToggleButton.setText("Humidifier_On");
                    logArea.setText(logArea.getText()+humidifierToggleButton.getText()+"\n");
                } else if (currentHumidity >= desiredHumidity && humidifierState) {
                    humidifierState = false;
                    humidifierToggleButton.setText("Humidifier_Off");
                    logArea.setText(logArea.getText()+humidifierToggleButton.getText()+"\n");
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    /**
     * Invoked when an action occurs.
     *
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == updateButton) {
            int sampleIncrement = Integer.parseInt(sampleIncrementInput.getText());
            int desiredHumidity = Integer.parseInt(rangeInput.getText());
            int humidifyingRate = Integer.parseInt(RateInput.getText());
            humidityThread.stop();

            // simulate measuring humidity
            currentHumidity += sampleIncrement;

            // update humidity label
            humidityLabel.setText("Current Humidity: " + currentHumidity + "%");
            logArea.setText(logArea.getText()+humidityLabel.getText()+"\n");

            // check if humidifier should be turned on or off
            if (currentHumidity < desiredHumidity) {
                humidifierState = true;
                humidifierToggleButton.setText("Humidifier_On");
                logArea.setText(logArea.getText()+humidifierToggleButton.getText()+"\n");
            } else {
                humidifierState = false;
                humidifierToggleButton.setText("Humidifier_Off");
                logArea.setText(logArea.getText()+humidifierToggleButton.getText()+"\n");
            }
        } else if (e.getSource() == humidifierToggleButton) {
            humidifierState = !humidifierState;
            if (humidifierState) {
                humidifierToggleButton.setText("Humidifier_On");
                logArea.setText(logArea.getText()+humidifierToggleButton.getText()+"\n");
            } else {
                humidifierToggleButton.setText("Humidifier_Off");
                logArea.setText(logArea.getText()+humidifierToggleButton.getText()+"\n");
            }
        }
        //for saving and viewing humidity data
        else if (e.getSource() == save3) {
            try {

                String fileName ="humidity.text";
                File file = new File(fileName);
                if (!file.exists()) {
                    file.createNewFile();
                }
                FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(sampleIncrementInput.getText()+ " " + rangeInput.getText() +" "+RateInput.getText()+" "+currentHumidity+" "+
                        humidifierToggleButton.getText()+" \n");
                bw.close();
                fw.close();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }}
        else if (e.getSource() == view3) {
            BufferedReader br = null;
            try {
                String fileName = "humidity.text";
                File file = new File(fileName);
                if (!file.exists()) {
                    JOptionPane.showMessageDialog(null, "No simulation saved yet!", "Warning", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                br = new BufferedReader(new FileReader(file));
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim(); // remove any leading/trailing whitespace
                    if (line.isEmpty()) {
                        continue; // skip empty lines
                    }
                    Vector<String> row2 = new Vector<>();
                    String[] parts2 = line.split(" ");
                    row2.add(parts2[0]);
                    row2.add(parts2[1]);
                    if (parts2.length >= 5) {
                        row2.add(parts2[2]);
                        row2.add(parts2[3]);
                        row2.add(parts2[4]);

                    }
                    data3.add(row2);
                }
                String[] columnNames = {"Sample Inc","Range","Rate:","Current Humidity","Humidifier"};
                String[][] dataArray = new String[data3.size()][2];
                for (int i = 0; i < data3.size(); i++) {
                    dataArray[i] = data3.get(i).toArray(new String[0]);
                }
                DefaultTableModel model1 = new DefaultTableModel(dataArray, columnNames);
                JTable table1= new JTable(model1);
                JFrame frame1 = new JFrame("Simulations");
                frame1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame1.getContentPane().add(new JScrollPane(table1));
                frame1.pack();
                frame1.setLocationRelativeTo(null);
                frame1.setVisible(true);

            } catch (Exception ex) {
                ex.printStackTrace();
            }}
        else if(e.getSource()==backButton)
        {
            new AutomatedGreenHouse().setVisible(true);
            setVisible(false);
        }
    }
}